import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "mediflow.db")

def get_connection():
    conn = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn

def initialize_db():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            username    TEXT UNIQUE NOT NULL,
            password    TEXT NOT NULL,
            role        TEXT NOT NULL CHECK(role IN ('admin','doctor','receptionist')),
            full_name   TEXT NOT NULL,
            created_at  TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS doctors (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL REFERENCES users(id),
            specialty   TEXT NOT NULL,
            available   INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS patients (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            name         TEXT NOT NULL,
            age          INTEGER,
            gender       TEXT,
            contact      TEXT,
            created_at   TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS appointments (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id   INTEGER NOT NULL REFERENCES patients(id),
            doctor_id    INTEGER NOT NULL REFERENCES doctors(id),
            date         TEXT NOT NULL,
            time_slot    TEXT NOT NULL,
            status       TEXT DEFAULT 'scheduled'
                         CHECK(status IN ('scheduled','cancelled','completed')),
            notes        TEXT,
            created_at   TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS queue (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id      INTEGER NOT NULL REFERENCES patients(id),
            doctor_id       INTEGER NOT NULL REFERENCES doctors(id),
            appointment_id  INTEGER REFERENCES appointments(id),
            state           TEXT DEFAULT 'registered'
                            CHECK(state IN ('registered','waiting','in_consultation','discharged')),
            token_number    INTEGER,
            queued_at       TEXT DEFAULT (datetime('now')),
            updated_at      TEXT DEFAULT (datetime('now'))
        );
    """)

    # Seed default admin
    cursor.execute("SELECT COUNT(*) FROM users")
    if cursor.fetchone()[0] == 0:
        cursor.executescript("""
            INSERT INTO users (username, password, role, full_name)
            VALUES ('admin', 'admin123', 'admin', 'System Administrator');

            INSERT INTO users (username, password, role, full_name)
            VALUES ('dr_ahmed', 'doc123', 'doctor', 'Dr. Ahmed Raza');

            INSERT INTO users (username, password, role, full_name)
            VALUES ('dr_sara', 'doc123', 'doctor', 'Dr. Sara Malik');

            INSERT INTO users (username, password, role, full_name)
            VALUES ('reception', 'rec123', 'receptionist', 'Fatima Noor');

            INSERT INTO doctors (user_id, specialty)
            VALUES (2, 'General Physician');

            INSERT INTO doctors (user_id, specialty)
            VALUES (3, 'Cardiologist');
        """)

    conn.commit()
    conn.close()
