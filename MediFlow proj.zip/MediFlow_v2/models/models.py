from database.db_connection import get_connection

class UserModel:
    @staticmethod
    def authenticate(username: str, password: str):
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM users WHERE username=? AND password=?",
                (username, password)
            )
            row = cursor.fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    @staticmethod
    def get_all():
        conn = get_connection()
        try:
            rows = conn.execute("SELECT * FROM users").fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def create(username, password, role, full_name):
        conn = get_connection()
        try:
            conn.execute(
                "INSERT INTO users (username,password,role,full_name) VALUES (?,?,?,?)",
                (username, password, role, full_name)
            )
            conn.commit()
            return True
        except Exception:
            return False
        finally:
            conn.close()


class DoctorModel:
    @staticmethod
    def get_all():
        conn = get_connection()
        try:
            rows = conn.execute("""
                SELECT d.id, d.user_id, d.specialty, d.available,
                       u.full_name, u.username
                FROM doctors d JOIN users u ON d.user_id = u.id
            """).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def get_by_id(doctor_id: int):
        conn = get_connection()
        try:
            row = conn.execute("""
                SELECT d.id, d.user_id, d.specialty, d.available,
                       u.full_name, u.username
                FROM doctors d JOIN users u ON d.user_id = u.id
                WHERE d.id = ?
            """, (doctor_id,)).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    @staticmethod
    def get_by_user_id(user_id: int):
        conn = get_connection()
        try:
            row = conn.execute(
                "SELECT * FROM doctors WHERE user_id = ?", (user_id,)
            ).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    @staticmethod
    def set_availability(doctor_id: int, available: bool):
        conn = get_connection()
        try:
            conn.execute(
                "UPDATE doctors SET available=? WHERE id=?",
                (1 if available else 0, doctor_id)
            )
            conn.commit()
        finally:
            conn.close()


class PatientModel:
    @staticmethod
    def get_all():
        conn = get_connection()
        try:
            rows = conn.execute("SELECT * FROM patients ORDER BY created_at DESC").fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def get_by_id(patient_id: int):
        conn = get_connection()
        try:
            row = conn.execute("SELECT * FROM patients WHERE id=?", (patient_id,)).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    @staticmethod
    def create(name: str, age: int, gender: str, contact: str) -> int:
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO patients (name,age,gender,contact) VALUES (?,?,?,?)",
                (name, age, gender, contact)
            )
            pid = cursor.lastrowid
            conn.commit()
            return pid
        finally:
            conn.close()

    @staticmethod
    def search(query: str):
        conn = get_connection()
        try:
            rows = conn.execute(
                "SELECT * FROM patients WHERE name LIKE ? OR contact LIKE ?",
                (f"%{query}%", f"%{query}%")
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()


class AppointmentModel:
    @staticmethod
    def get_all():
        conn = get_connection()
        try:
            rows = conn.execute("""
                SELECT a.*, p.name as patient_name, u.full_name as doctor_name
                FROM appointments a
                JOIN patients p ON a.patient_id = p.id
                JOIN doctors d ON a.doctor_id = d.id
                JOIN users u ON d.user_id = u.id
                ORDER BY a.date DESC, a.time_slot
            """).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def get_by_id(appt_id: int):
        conn = get_connection()
        try:
            row = conn.execute("""
                SELECT a.*, p.name as patient_name, u.full_name as doctor_name
                FROM appointments a
                JOIN patients p ON a.patient_id = p.id
                JOIN doctors d ON a.doctor_id = d.id
                JOIN users u ON d.user_id = u.id
                WHERE a.id = ?
            """, (appt_id,)).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    @staticmethod
    def get_by_doctor(doctor_id: int):
        conn = get_connection()
        try:
            rows = conn.execute("""
                SELECT a.*, p.name as patient_name
                FROM appointments a
                JOIN patients p ON a.patient_id = p.id
                WHERE a.doctor_id = ? AND a.status = 'scheduled'
                ORDER BY a.date, a.time_slot
            """, (doctor_id,)).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def get_today(doctor_id: int = None):
        conn = get_connection()
        try:
            if doctor_id:
                rows = conn.execute("""
                    SELECT a.*, p.name as patient_name, u.full_name as doctor_name
                    FROM appointments a
                    JOIN patients p ON a.patient_id = p.id
                    JOIN doctors d ON a.doctor_id = d.id
                    JOIN users u ON d.user_id = u.id
                    WHERE a.doctor_id = ? AND a.date = date('now') AND a.status='scheduled'
                    ORDER BY a.time_slot
                """, (doctor_id,)).fetchall()
            else:
                rows = conn.execute("""
                    SELECT a.*, p.name as patient_name, u.full_name as doctor_name
                    FROM appointments a
                    JOIN patients p ON a.patient_id = p.id
                    JOIN doctors d ON a.doctor_id = d.id
                    JOIN users u ON d.user_id = u.id
                    WHERE a.date = date('now') AND a.status='scheduled'
                    ORDER BY a.time_slot
                """).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def count_by_status():
        conn = get_connection()
        try:
            rows = conn.execute("""
                SELECT status, COUNT(*) as count FROM appointments GROUP BY status
            """).fetchall()
            return {r["status"]: r["count"] for r in rows}
        finally:
            conn.close()


class QueueModel:
    @staticmethod
    def get_active():
        conn = get_connection()
        try:
            rows = conn.execute("""
                SELECT q.*, p.name as patient_name, u.full_name as doctor_name
                FROM queue q
                JOIN patients p ON q.patient_id = p.id
                JOIN doctors d ON q.doctor_id = d.id
                JOIN users u ON d.user_id = u.id
                WHERE q.state != 'discharged'
                ORDER BY q.token_number
            """).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def get_all_today():
        conn = get_connection()
        try:
            rows = conn.execute("""
                SELECT q.*, p.name as patient_name, u.full_name as doctor_name
                FROM queue q
                JOIN patients p ON q.patient_id = p.id
                JOIN doctors d ON q.doctor_id = d.id
                JOIN users u ON d.user_id = u.id
                WHERE date(q.queued_at) = date('now')
                ORDER BY q.token_number
            """).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    @staticmethod
    def add_to_queue(patient_id: int, doctor_id: int, appointment_id: int = None) -> int:
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT COALESCE(MAX(token_number), 0) + 1
                FROM queue
                WHERE doctor_id = ? AND date(queued_at) = date('now')
            """, (doctor_id,))
            token = cursor.fetchone()[0]
            cursor.execute("""
                INSERT INTO queue (patient_id, doctor_id, appointment_id, state, token_number)
                VALUES (?, ?, ?, 'registered', ?)
            """, (patient_id, doctor_id, appointment_id, token))
            qid = cursor.lastrowid
            conn.commit()
            return qid
        finally:
            conn.close()

    @staticmethod
    def update_state(queue_id: int, new_state: str):
        conn = get_connection()
        try:
            conn.execute("""
                UPDATE queue SET state=?, updated_at=datetime('now') WHERE id=?
            """, (new_state, queue_id))
            conn.commit()
        finally:
            conn.close()

    @staticmethod
    def get_by_id(queue_id: int):
        conn = get_connection()
        try:
            row = conn.execute("""
                SELECT q.*, p.name as patient_name, u.full_name as doctor_name
                FROM queue q
                JOIN patients p ON q.patient_id = p.id
                JOIN doctors d ON q.doctor_id = d.id
                JOIN users u ON d.user_id = u.id
                WHERE q.id = ?
            """, (queue_id,)).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    @staticmethod
    def count_by_state():
        conn = get_connection()
        try:
            rows = conn.execute("""
                SELECT state, COUNT(*) as count FROM queue
                WHERE date(queued_at) = date('now')
                GROUP BY state
            """).fetchall()
            return {r["state"]: r["count"] for r in rows}
        finally:
            conn.close()