"""
MVC — CONTROLLER LAYER
Controllers coordinate between Models, Patterns, and Views.
They contain all business logic — Views never touch Models directly.
"""

from models.models import (
    UserModel, DoctorModel, PatientModel,
    AppointmentModel, QueueModel
)
from patterns.observer import queue_manager
from patterns.state import PatientContext, state_from_string
from patterns.command import (
    BookAppointmentCommand, CancelAppointmentCommand,
    RescheduleAppointmentCommand, invoker
)


# ─────────────────────────────────────────────────────────────────────────────
# AuthController
# ─────────────────────────────────────────────────────────────────────────────
class AuthController:
    _current_user = None

    @classmethod
    def login(cls, username: str, password: str) -> dict | None:
        user = UserModel.authenticate(username.strip(), password.strip())
        if user:
            cls._current_user = user
        return user

    @classmethod
    def logout(cls):
        cls._current_user = None

    @classmethod
    def current_user(cls) -> dict | None:
        return cls._current_user

    @classmethod
    def is_admin(cls) -> bool:
        return cls._current_user and cls._current_user["role"] == "admin"

    @classmethod
    def is_doctor(cls) -> bool:
        return cls._current_user and cls._current_user["role"] == "doctor"

    @classmethod
    def is_receptionist(cls) -> bool:
        return cls._current_user and cls._current_user["role"] == "receptionist"


# ─────────────────────────────────────────────────────────────────────────────
# PatientController
# ─────────────────────────────────────────────────────────────────────────────
class PatientController:
    @staticmethod
    def register_patient(name: str, age: int, gender: str, contact: str) -> tuple[bool, str]:
        if not name.strip():
            return False, "Patient name is required."
        if age < 0 or age > 150:
            return False, "Please enter a valid age."
        pid = PatientModel.create(name.strip(), age, gender, contact.strip())
        return True, f"Patient registered with ID #{pid}"

    @staticmethod
    def get_all_patients():
        return PatientModel.get_all()

    @staticmethod
    def search_patients(query: str):
        return PatientModel.search(query)

    @staticmethod
    def get_patient(patient_id: int):
        return PatientModel.get_by_id(patient_id)


# ─────────────────────────────────────────────────────────────────────────────
# AppointmentController  (uses Command Pattern)
# ─────────────────────────────────────────────────────────────────────────────
class AppointmentController:
    @staticmethod
    def book(patient_id: int, doctor_id: int, date: str, time_slot: str, notes: str = "") -> tuple[bool, str]:
        if not date or not time_slot:
            return False, "Date and time slot are required."
        cmd = BookAppointmentCommand(patient_id, doctor_id, date, time_slot, notes)
        success = invoker.execute(cmd)
        if success:
            return True, "Appointment booked successfully."
        return False, "Failed to book appointment."

    @staticmethod
    def cancel(appointment_id: int) -> tuple[bool, str]:
        cmd = CancelAppointmentCommand(appointment_id)
        success = invoker.execute(cmd)
        if success:
            return True, "Appointment cancelled."
        return False, "Failed to cancel appointment."

    @staticmethod
    def reschedule(appointment_id: int, new_date: str, new_time_slot: str) -> tuple[bool, str]:
        if not new_date or not new_time_slot:
            return False, "New date and time slot are required."
        cmd = RescheduleAppointmentCommand(appointment_id, new_date, new_time_slot)
        success = invoker.execute(cmd)
        if success:
            return True, "Appointment rescheduled."
        return False, "Failed to reschedule."

    @staticmethod
    def undo() -> str:
        result = invoker.undo()
        return result or "Nothing to undo."

    @staticmethod
    def redo() -> str:
        result = invoker.redo()
        return result or "Nothing to redo."

    @staticmethod
    def can_undo() -> bool:
        return invoker.can_undo()

    @staticmethod
    def can_redo() -> bool:
        return invoker.can_redo()

    @staticmethod
    def get_all():
        return AppointmentModel.get_all()

    @staticmethod
    def get_today(doctor_id=None):
        return AppointmentModel.get_today(doctor_id)

    @staticmethod
    def get_by_id(appt_id):
        return AppointmentModel.get_by_id(appt_id)


# ─────────────────────────────────────────────────────────────────────────────
# QueueController  (uses Observer + State Patterns)
# ─────────────────────────────────────────────────────────────────────────────
class QueueController:
    @staticmethod
    def add_to_queue(patient_id: int, doctor_id: int, appointment_id: int = None) -> tuple[bool, str]:
        patient = PatientModel.get_by_id(patient_id)
        doctor  = DoctorModel.get_by_id(doctor_id)
        if not patient:
            return False, "Patient not found."
        if not doctor:
            return False, "Doctor not found."
        if not doctor["available"]:
            return False, f"Dr. {doctor['full_name']} is currently unavailable."

        qid = QueueModel.add_to_queue(patient_id, doctor_id, appointment_id)
        entry = QueueModel.get_by_id(qid)

        # Observer: notify all watchers
        queue_manager.patient_added(
            patient_name=patient["name"],
            token=entry["token_number"],
            doctor_name=doctor["full_name"]
        )
        return True, f"Token #{entry['token_number']} assigned to {patient['name']}"

    @staticmethod
    def advance_state(queue_id: int) -> tuple[bool, str]:
        entry = QueueModel.get_by_id(queue_id)
        if not entry:
            return False, "Queue entry not found."

        # State pattern: advance through lifecycle
        context = state_from_string(entry["state"])
        if not context.can_advance():
            return False, f"Patient is already {context.get_current_label()}."

        new_state = context.advance()
        QueueModel.update_state(queue_id, new_state)

        # Observer: notify watchers
        queue_manager.update_patient_state(
            queue_id=queue_id,
            new_state=new_state,
            patient_name=entry["patient_name"]
        )
        if new_state == "discharged":
            queue_manager.patient_discharged(entry["patient_name"])

        return True, f"{entry['patient_name']} → {context.get_current_label()}"

    @staticmethod
    def get_active_queue():
        return QueueModel.get_active()

    @staticmethod
    def get_today_queue():
        return QueueModel.get_all_today()

    @staticmethod
    def get_stats():
        return QueueModel.count_by_state()


# ─────────────────────────────────────────────────────────────────────────────
# DoctorController
# ─────────────────────────────────────────────────────────────────────────────
class DoctorController:
    @staticmethod
    def get_all():
        return DoctorModel.get_all()

    @staticmethod
    def toggle_availability(doctor_id: int) -> tuple[bool, str]:
        doctor = DoctorModel.get_by_id(doctor_id)
        if not doctor:
            return False, "Doctor not found."
        new_status = not doctor["available"]
        DoctorModel.set_availability(doctor_id, new_status)
        status_str = "Available" if new_status else "Unavailable"
        return True, f"Dr. {doctor['full_name']} marked as {status_str}."

    @staticmethod
    def get_today_appointments(user_id: int):
        doc = DoctorModel.get_by_user_id(user_id)
        if not doc:
            return []
        return AppointmentModel.get_today(doc["id"])

    @staticmethod
    def get_doctor_by_user(user_id: int):
        return DoctorModel.get_by_user_id(user_id)


# ─────────────────────────────────────────────────────────────────────────────
# AdminController
# ─────────────────────────────────────────────────────────────────────────────
class AdminController:
    @staticmethod
    def get_dashboard_stats() -> dict:
        appt_stats  = AppointmentModel.count_by_status()
        queue_stats = QueueModel.count_by_state()
        all_patients = PatientModel.get_all()
        all_doctors  = DoctorModel.get_all()
        return {
            "total_patients":     len(all_patients),
            "total_doctors":      len(all_doctors),
            "appointments_today": len(AppointmentModel.get_today()),
            "scheduled":          appt_stats.get("scheduled", 0),
            "cancelled":          appt_stats.get("cancelled", 0),
            "completed":          appt_stats.get("completed", 0),
            "queue_waiting":      queue_stats.get("waiting", 0),
            "queue_in_consult":   queue_stats.get("in_consultation", 0),
            "queue_discharged":   queue_stats.get("discharged", 0),
        }

    @staticmethod
    def create_user(username, password, role, full_name) -> tuple[bool, str]:
        if not username or not password or not full_name:
            return False, "All fields are required."
        success = UserModel.create(username, password, role, full_name)
        return (True, "User created.") if success else (False, "Username already exists.")

    @staticmethod
    def get_all_users():
        return UserModel.get_all()
