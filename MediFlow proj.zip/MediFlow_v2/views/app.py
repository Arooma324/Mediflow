"""
MVC — VIEW LAYER (Flask Web GUI)
All routes call Controllers only. No direct Model access here.
"""

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash, Response
from controllers.controllers import (
    AuthController, PatientController, AppointmentController,
    QueueController, DoctorController, AdminController
)
import functools
import csv
import io
import os
from datetime import datetime

app = Flask(__name__,
            template_folder=os.path.join(os.path.dirname(__file__), '..', 'templates'),
            static_folder=os.path.join(os.path.dirname(__file__), '..', 'static'))
app.secret_key = "mediflow_secret_2024"


# ── Auth guard ────────────────────────────────────────────────────────────────
def login_required(f):
    @functools.wraps(f)
    def decorated(*args, **kwargs):
        if "user" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated


# ── CSV helper ────────────────────────────────────────────────────────────────
def make_csv_response(headers, rows, filename):
    """Build a downloadable CSV Response from a list of dicts."""
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=headers, extrasaction='ignore')
    writer.writeheader()
    writer.writerows(rows)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    fname = f"{filename}_{timestamp}.csv"
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={fname}"}
    )


# ── Login ─────────────────────────────────────────────────────────────────────
@app.route("/", methods=["GET", "POST"])
@app.route("/login", methods=["GET", "POST"])
def login():
    if "user" in session:
        return redirect(url_for("dashboard"))
    error = None
    if request.method == "POST":
        user = AuthController.login(request.form["username"], request.form["password"])
        if user:
            session["user"] = user
            return redirect(url_for("dashboard"))
        error = "Invalid username or password."
    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ── Dashboard ─────────────────────────────────────────────────────────────────
@app.route("/dashboard")
@login_required
def dashboard():
    stats = AdminController.get_dashboard_stats()
    return render_template("dashboard.html", stats=stats, user=session["user"])


# ── Patients ──────────────────────────────────────────────────────────────────
@app.route("/patients")
@login_required
def patients():
    q = request.args.get("q", "")
    if q:
        rows = PatientController.search_patients(q)
    else:
        rows = PatientController.get_all_patients()
    return render_template("patients.html", patients=rows, user=session["user"], q=q)


@app.route("/patients/register", methods=["POST"])
@login_required
def register_patient():
    ok, msg = PatientController.register_patient(
        request.form["name"],
        int(request.form.get("age", 0)),
        request.form.get("gender", ""),
        request.form.get("contact", "")
    )
    flash(msg, "success" if ok else "error")
    return redirect(url_for("patients"))


@app.route("/patients/export")
@login_required
def export_patients():
    rows = PatientController.get_all_patients()
    headers = ["id", "name", "age", "gender", "contact", "created_at"]
    return make_csv_response(headers, rows, "mediflow_patients")


# ── Appointments ──────────────────────────────────────────────────────────────
@app.route("/appointments")
@login_required
def appointments():
    rows = AppointmentController.get_all()
    doctors = DoctorController.get_all()
    patients_list = PatientController.get_all_patients()
    can_undo = AppointmentController.can_undo()
    can_redo = AppointmentController.can_redo()
    return render_template("appointments.html",
                           appointments=rows, doctors=doctors,
                           patients=patients_list, user=session["user"],
                           can_undo=can_undo, can_redo=can_redo)


@app.route("/appointments/book", methods=["POST"])
@login_required
def book_appointment():
    ok, msg = AppointmentController.book(
        int(request.form["patient_id"]),
        int(request.form["doctor_id"]),
        request.form["date"],
        request.form["time_slot"],
        request.form.get("notes", "")
    )
    flash(msg, "success" if ok else "error")
    return redirect(url_for("appointments"))


@app.route("/appointments/cancel/<int:appt_id>", methods=["POST"])
@login_required
def cancel_appointment(appt_id):
    ok, msg = AppointmentController.cancel(appt_id)
    flash(msg, "success" if ok else "error")
    return redirect(url_for("appointments"))


@app.route("/appointments/undo", methods=["POST"])
@login_required
def undo_appointment():
    msg = AppointmentController.undo()
    flash(msg, "info")
    return redirect(url_for("appointments"))


@app.route("/appointments/redo", methods=["POST"])
@login_required
def redo_appointment():
    msg = AppointmentController.redo()
    flash(msg, "info")
    return redirect(url_for("appointments"))


@app.route("/appointments/export")
@login_required
def export_appointments():
    rows = AppointmentController.get_all()
    headers = ["id", "patient_name", "doctor_name", "date", "time_slot", "status", "notes", "created_at"]
    return make_csv_response(headers, rows, "mediflow_appointments")


# ── Queue ─────────────────────────────────────────────────────────────────────
@app.route("/queue")
@login_required
def queue():
    active = QueueController.get_active_queue()
    today  = QueueController.get_today_queue()
    doctors = DoctorController.get_all()
    patients_list = PatientController.get_all_patients()
    stats  = QueueController.get_stats()
    return render_template("queue.html",
                           active=active, today=today,
                           doctors=doctors, patients=patients_list,
                           stats=stats, user=session["user"])


@app.route("/queue/add", methods=["POST"])
@login_required
def add_to_queue():
    aid = request.form.get("appointment_id")
    ok, msg = QueueController.add_to_queue(
        int(request.form["patient_id"]),
        int(request.form["doctor_id"]),
        int(aid) if aid and aid.isdigit() else None
    )
    flash(msg, "success" if ok else "error")
    return redirect(url_for("queue"))


@app.route("/queue/advance/<int:queue_id>", methods=["POST"])
@login_required
def advance_queue(queue_id):
    ok, msg = QueueController.advance_state(queue_id)
    flash(msg, "success" if ok else "error")
    return redirect(url_for("queue"))


@app.route("/queue/export")
@login_required
def export_queue():
    rows = QueueController.get_today_queue()
    headers = ["id", "token_number", "patient_name", "doctor_name", "state", "queued_at", "updated_at"]
    return make_csv_response(headers, rows, "mediflow_queue_today")


# ── Doctors ───────────────────────────────────────────────────────────────────
@app.route("/doctors")
@login_required
def doctors():
    rows = DoctorController.get_all()
    return render_template("doctors.html", doctors=rows, user=session["user"])


@app.route("/doctors/toggle/<int:doctor_id>", methods=["POST"])
@login_required
def toggle_doctor(doctor_id):
    ok, msg = DoctorController.toggle_availability(doctor_id)
    flash(msg, "success" if ok else "error")
    return redirect(url_for("doctors"))


# ── API: live queue data for auto-refresh ─────────────────────────────────────
@app.route("/api/queue")
@login_required
def api_queue():
    return jsonify(QueueController.get_active_queue())


@app.route("/api/stats")
@login_required
def api_stats():
    return jsonify(AdminController.get_dashboard_stats())


if __name__ == "__main__":
    app.run(debug=True, port=5000)
