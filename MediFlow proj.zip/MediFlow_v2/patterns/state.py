"""
DESIGN PATTERN 2: STATE PATTERN
----------------------------------
Intent: Allow an object to alter its behavior when its internal
state changes. The object will appear to change its class.

Usage in MediFlow:
- A patient's queue entry moves through: Registered → Waiting →
  In-Consultation → Discharged.
- Each state knows which transitions are valid and raises an error
  for illegal transitions (e.g., Discharged → Waiting).
"""

from abc import ABC, abstractmethod


# ── Abstract State ────────────────────────────────────────────────────────────
class PatientState(ABC):
    @abstractmethod
    def next_state(self, context: "PatientContext") -> str:
        pass

    @abstractmethod
    def get_label(self) -> str:
        pass

    @abstractmethod
    def get_allowed_transitions(self) -> list[str]:
        pass


# ── Concrete States ───────────────────────────────────────────────────────────
class RegisteredState(PatientState):
    def next_state(self, context: "PatientContext"):
        context.set_state(WaitingState())
        return "waiting"

    def get_label(self) -> str:
        return "Registered"

    def get_allowed_transitions(self) -> list[str]:
        return ["waiting"]


class WaitingState(PatientState):
    def next_state(self, context: "PatientContext"):
        context.set_state(InConsultationState())
        return "in_consultation"

    def get_label(self) -> str:
        return "Waiting"

    def get_allowed_transitions(self) -> list[str]:
        return ["in_consultation"]


class InConsultationState(PatientState):
    def next_state(self, context: "PatientContext"):
        context.set_state(DischargedState())
        return "discharged"

    def get_label(self) -> str:
        return "In Consultation"

    def get_allowed_transitions(self) -> list[str]:
        return ["discharged"]


class DischargedState(PatientState):
    def next_state(self, context: "PatientContext"):
        raise ValueError("Patient is already discharged. No further transitions allowed.")

    def get_label(self) -> str:
        return "Discharged"

    def get_allowed_transitions(self) -> list[str]:
        return []


# ── Context ───────────────────────────────────────────────────────────────────
class PatientContext:
    """
    Holds the current state of a patient in the queue.
    Delegates state-specific behavior to the current state object.
    """
    STATE_MAP = {
        "registered":      RegisteredState,
        "waiting":         WaitingState,
        "in_consultation": InConsultationState,
        "discharged":      DischargedState,
    }

    def __init__(self, initial_state: str = "registered"):
        self._state: PatientState = self.STATE_MAP[initial_state]()

    def set_state(self, state: PatientState):
        self._state = state

    def advance(self) -> str:
        """Move to the next valid state and return the new state string."""
        return self._state.next_state(self)

    def get_current_label(self) -> str:
        return self._state.get_label()

    def get_current_key(self) -> str:
        for key, cls in self.STATE_MAP.items():
            if isinstance(self._state, cls):
                return key
        return "unknown"

    def can_advance(self) -> bool:
        return bool(self._state.get_allowed_transitions())


def state_from_string(state_str: str) -> PatientContext:
    """Factory helper to restore a PatientContext from a DB string."""
    return PatientContext(initial_state=state_str)
