from abc import ABC, abstractmethod
from database.db_connection import get_connection
from datetime import datetime


class Command(ABC):
    @abstractmethod
    def execute(self) -> bool:
        pass

    @abstractmethod
    def undo(self) -> bool:
        pass

    @abstractmethod
    def description(self) -> str:
        pass


class BookAppointmentCommand(Command):
    def __init__(self, patient_id: int, doctor_id: int, date: str, time_slot: str, notes: str = ""):
        self.patient_id  = patient_id
        self.doctor_id   = doctor_id
        self.date        = date
        self.time_slot   = time_slot
        self.notes       = notes
        self._created_id = None

    def execute(self) -> bool:
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO appointments (patient_id, doctor_id, date, time_slot, notes, status)
                VALUES (?, ?, ?, ?, ?, 'scheduled')
            """, (self.patient_id, self.doctor_id, self.date, self.time_slot, self.notes))
            self._created_id = cursor.lastrowid
            conn.commit()
            return True
        except Exception as e:
            print(f"BookAppointmentCommand.execute error: {e}")
            return False
        finally:
            conn.close()

    def undo(self) -> bool:
        if self._created_id is None:
            return False
        conn = get_connection()
        try:
            conn.execute("DELETE FROM appointments WHERE id = ?", (self._created_id,))
            conn.commit()
            return True
        except Exception as e:
            print(f"BookAppointmentCommand.undo error: {e}")
            return False
        finally:
            conn.close()

    def description(self) -> str:
        return f"Book appointment (Patient #{self.patient_id}, Doctor #{self.doctor_id}, {self.date} {self.time_slot})"


class CancelAppointmentCommand(Command):
    def __init__(self, appointment_id: int):
        self.appointment_id   = appointment_id
        self._previous_status = None

    def execute(self) -> bool:
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT status FROM appointments WHERE id = ?", (self.appointment_id,))
            row = cursor.fetchone()
            if not row:
                return False
            self._previous_status = row["status"]
            cursor.execute("UPDATE appointments SET status='cancelled' WHERE id = ?", (self.appointment_id,))
            conn.commit()
            return True
        except Exception as e:
            print(f"CancelAppointmentCommand.execute error: {e}")
            return False
        finally:
            conn.close()

    def undo(self) -> bool:
        if self._previous_status is None:
            return False
        conn = get_connection()
        try:
            conn.execute("UPDATE appointments SET status=? WHERE id = ?",
                         (self._previous_status, self.appointment_id))
            conn.commit()
            return True
        except Exception as e:
            print(f"CancelAppointmentCommand.undo error: {e}")
            return False
        finally:
            conn.close()

    def description(self) -> str:
        return f"Cancel appointment #{self.appointment_id}"


class RescheduleAppointmentCommand(Command):
    def __init__(self, appointment_id: int, new_date: str, new_time_slot: str):
        self.appointment_id = appointment_id
        self.new_date       = new_date
        self.new_time_slot  = new_time_slot
        self._old_date      = None
        self._old_time_slot = None

    def execute(self) -> bool:
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT date, time_slot FROM appointments WHERE id = ?", (self.appointment_id,))
            row = cursor.fetchone()
            if not row:
                return False
            self._old_date      = row["date"]
            self._old_time_slot = row["time_slot"]
            cursor.execute("""
                UPDATE appointments SET date=?, time_slot=?, status='scheduled' WHERE id=?
            """, (self.new_date, self.new_time_slot, self.appointment_id))
            conn.commit()
            return True
        except Exception as e:
            print(f"RescheduleAppointmentCommand.execute error: {e}")
            return False
        finally:
            conn.close()

    def undo(self) -> bool:
        if self._old_date is None:
            return False
        conn = get_connection()
        try:
            conn.execute("UPDATE appointments SET date=?, time_slot=? WHERE id=?",
                         (self._old_date, self._old_time_slot, self.appointment_id))
            conn.commit()
            return True
        except Exception as e:
            print(f"RescheduleAppointmentCommand.undo error: {e}")
            return False
        finally:
            conn.close()

    def description(self) -> str:
        return f"Reschedule appointment #{self.appointment_id} to {self.new_date} {self.new_time_slot}"


class CommandInvoker:
    def __init__(self):
        self._history:    list[Command] = []
        self._redo_stack: list[Command] = []

    def execute(self, command: Command) -> bool:
        success = command.execute()
        if success:
            self._history.append(command)
            self._redo_stack.clear()
        return success

    def undo(self) -> str | None:
        if not self._history:
            return None
        command = self._history.pop()
        command.undo()
        self._redo_stack.append(command)
        return f"Undone: {command.description()}"

    def redo(self) -> str | None:
        if not self._redo_stack:
            return None
        command = self._redo_stack.pop()
        command.execute()
        self._history.append(command)
        return f"Redone: {command.description()}"

    def can_undo(self) -> bool:
        return bool(self._history)

    def can_redo(self) -> bool:
        return bool(self._redo_stack)

    def history_log(self) -> list[str]:
        return [c.description() for c in self._history]


invoker = CommandInvoker()