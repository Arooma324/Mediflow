"""
DESIGN PATTERN 1: OBSERVER PATTERN
------------------------------------
Intent: Define a one-to-many dependency so that when one object
changes state, all its dependents are notified automatically.

Usage in MediFlow:
- When a patient's queue state changes, all registered observers
  (DoctorDashboard, ReceptionDesk, QueueDisplay) are notified
  automatically without tight coupling between components.
"""

from abc import ABC, abstractmethod


# ── Abstract Subject ─────────────────────────────────────────────────────────
class Subject(ABC):
    def __init__(self):
        self._observers: list["Observer"] = []

    def attach(self, observer: "Observer"):
        if observer not in self._observers:
            self._observers.append(observer)

    def detach(self, observer: "Observer"):
        self._observers.remove(observer)

    def notify(self, event: str, data: dict = None):
        for observer in self._observers:
            observer.update(event, data or {})


# ── Abstract Observer ─────────────────────────────────────────────────────────
class Observer(ABC):
    @abstractmethod
    def update(self, event: str, data: dict):
        pass


# ── Concrete Subject: QueueManager ───────────────────────────────────────────
class QueueManager(Subject):
    """
    Central subject that holds queue state.
    Notifies all registered dashboard/view observers on any change.
    """
    def __init__(self):
        super().__init__()
        self._queue_data = []

    def update_patient_state(self, queue_id: int, new_state: str, patient_name: str):
        self.notify("state_changed", {
            "queue_id": queue_id,
            "new_state": new_state,
            "patient_name": patient_name
        })

    def patient_added(self, patient_name: str, token: int, doctor_name: str):
        self.notify("patient_added", {
            "patient_name": patient_name,
            "token": token,
            "doctor_name": doctor_name
        })

    def patient_discharged(self, patient_name: str):
        self.notify("patient_discharged", {"patient_name": patient_name})


# ── Concrete Observer: QueueDisplayObserver ───────────────────────────────────
class QueueDisplayObserver(Observer):
    """Attached to the live queue table in the GUI."""
    def __init__(self, refresh_callback):
        self._refresh = refresh_callback

    def update(self, event: str, data: dict):
        self._refresh(event, data)


# ── Concrete Observer: NotificationObserver ───────────────────────────────────
class NotificationObserver(Observer):
    """Logs events to the notification panel."""
    def __init__(self, log_callback):
        self._log = log_callback

    def update(self, event: str, data: dict):
        if event == "state_changed":
            msg = f"[Queue Update] {data['patient_name']} → {data['new_state'].replace('_', ' ').title()}"
        elif event == "patient_added":
            msg = f"[New Patient] {data['patient_name']} (Token #{data['token']}) assigned to {data['doctor_name']}"
        elif event == "patient_discharged":
            msg = f"[Discharged] {data['patient_name']} has been discharged."
        else:
            msg = f"[Event] {event}: {data}"
        self._log(msg)


# ── Global singleton queue manager ───────────────────────────────────────────
queue_manager = QueueManager()
